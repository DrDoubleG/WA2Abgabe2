function send() {
  alert('Ihre Anfrage wird beartbeitet!');
  setTimeout("window.location.href='index.html'", 4000);
}
